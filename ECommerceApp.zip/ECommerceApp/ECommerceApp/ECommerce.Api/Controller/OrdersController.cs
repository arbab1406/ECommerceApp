﻿using ECommerce.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ECommerce.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderService _orderService;

        public OrdersController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        // ✅ Buyers place orders
        [HttpPost]
        [Authorize(Roles = "Buyer")]
        public async Task<IActionResult> PlaceOrder()
        {
            try
            {
                var buyerId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

                if (string.IsNullOrEmpty(buyerId))
                {
                    return BadRequest("Unable to identify buyer");
                }

                var order = await _orderService.PlaceOrderAsync(buyerId);

                if (order == null)
                {
                    return BadRequest("Unable to place order. Cart may be empty.");
                }

                return Ok(new { message = "Order placed successfully", order });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while placing the order", error = ex.Message });
            }
        }

        // ✅ Buyers view their own orders
        [HttpGet("buyer")]
        [Authorize(Roles = "Buyer")]
        public async Task<IActionResult> GetOrdersForBuyer()
        {
            try
            {
                var buyerId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

                if (string.IsNullOrEmpty(buyerId))
                {
                    return BadRequest("Unable to identify buyer");
                }

                var orders = await _orderService.GetOrdersByBuyerAsync(buyerId);
                return Ok(orders);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while retrieving orders", error = ex.Message });
            }
        }

        // ✅ Sellers view their received orders
        [HttpGet("seller")]
        [Authorize(Roles = "Seller")]
        public async Task<IActionResult> GetOrdersForSeller()
        {
            try
            {
                var sellerId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

                if (string.IsNullOrEmpty(sellerId))
                {
                    return BadRequest("Unable to identify seller");
                }

                var orders = await _orderService.GetOrdersBySellerAsync(sellerId);
                return Ok(orders);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while retrieving orders", error = ex.Message });
            }
        }

        // ✅ Get specific order details (accessible by both buyer and seller)
        [HttpGet("{orderId:int}")]
        [Authorize]
        public async Task<IActionResult> GetOrderById(int orderId)
        {
            try
            {
                var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var userRole = User.FindFirst(ClaimTypes.Role)?.Value;

                if (string.IsNullOrEmpty(userId))
                {
                    return BadRequest("Unable to identify user");
                }

                var order = await _orderService.GetOrderByIdAsync(orderId);

                if (order == null)
                {
                    return NotFound("Order not found");
                }

                // Check if user has permission to view this order
                bool canView = userRole switch
                {
                    "Buyer" => order.BuyerId == userId,
                    "Seller" => await _orderService.IsSellerOrderAsync(orderId, userId),
                    "Admin" => true,
                    _ => false
                };

                if (!canView)
                {
                    return Forbid("You don't have permission to view this order");
                }

                return Ok(order);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while retrieving the order", error = ex.Message });
            }
        }

        // ✅ Update order status (for sellers)
        [HttpPatch("{orderId:int}/status")]
        [Authorize(Roles = "Seller")]
        public async Task<IActionResult> UpdateOrderStatus(int orderId, [FromBody] UpdateOrderStatusRequest request)
        {
            try
            {
                var sellerId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

                if (string.IsNullOrEmpty(sellerId))
                {
                    return BadRequest("Unable to identify seller");
                }

                var success = await _orderService.UpdateOrderStatusAsync(orderId, sellerId, request.Status);

                if (!success)
                {
                    return BadRequest("Unable to update order status. Order may not exist or you may not have permission.");
                }

                return Ok(new { message = "Order status updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while updating order status", error = ex.Message });
            }
        }

        // ✅ Cancel order (for buyers)
        [HttpPatch("{orderId:int}/cancel")]
        [Authorize(Roles = "Buyer")]
        public async Task<IActionResult> CancelOrder(int orderId)
        {
            try
            {
                var buyerId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

                if (string.IsNullOrEmpty(buyerId))
                {
                    return BadRequest("Unable to identify buyer");
                }

                var success = await _orderService.CancelOrderAsync(orderId, buyerId);

                if (!success)
                {
                    return BadRequest("Unable to cancel order. Order may not exist, may not belong to you, or may already be shipped.");
                }

                return Ok(new { message = "Order cancelled successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while cancelling the order", error = ex.Message });
            }
        }
    }

    // DTO for updating order status
    public class UpdateOrderStatusRequest
    {
        public string Status { get; set; } = string.Empty;
    }
}