﻿using ECommerce.Application.DTOs;
using ECommerce.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ECommerce.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _productService;

        public ProductsController(IProductService productService)
        {
            _productService = productService;
        }

        // ✅ GET all products - Anonymous access
        [AllowAnonymous]
        [HttpGet]
        public async Task<IActionResult> GetProducts()
        {
            try
            {
                var products = await _productService.GetAllProductsAsync();
                return Ok(products);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "An error occurred while retrieving products.", Error = ex.Message });
            }
        }

        // ✅ GET product by ID - Anonymous access
        [AllowAnonymous]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetProduct(int id)
        {
            try
            {
                var product = await _productService.GetProductByIdAsync(id);
                if (product == null)
                    return NotFound(new { Message = "Product not found." });

                return Ok(product);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "An error occurred while retrieving the product.", Error = ex.Message });
            }
        }

        // ✅ GET products by seller - Requires authentication
        [Authorize(Roles = "Admin,Seller")]
        [HttpGet("seller/{sellerId}")]
        public async Task<IActionResult> GetProductsBySeller(string sellerId)
        {
            try
            {
                var products = await _productService.GetProductsBySellerIdAsync(sellerId);
                return Ok(products);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "An error occurred while retrieving seller products.", Error = ex.Message });
            }
        }

        // ✅ GET current user's products - Requires authentication
        [Authorize(Roles = "Seller")]
        [HttpGet("my-products")]
        public async Task<IActionResult> GetMyProducts()
        {
            try
            {
                var sellerId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(sellerId))
                    return BadRequest(new { Message = "Seller ID not found." });

                var products = await _productService.GetProductsBySellerIdAsync(sellerId);
                return Ok(products);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "An error occurred while retrieving your products.", Error = ex.Message });
            }
        }

        // ✅ POST add product - Requires authentication (Seller only)
        [Authorize(Roles = "Seller")]
        [HttpPost("add")]
        public async Task<IActionResult> AddProduct([FromBody] CreateProductDto dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var sellerId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(sellerId))
                    return BadRequest(new { Message = "Seller ID not found." });

                var product = await _productService.AddProductAsync(dto, sellerId);

                return CreatedAtAction(nameof(GetProduct), new { id = product.Id }, product);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "An error occurred while adding the product.", Error = ex.Message });
            }
        }

        // ✅ PUT update product - Requires authentication (Seller only, own products)
        [Authorize(Roles = "Seller")]
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct(int id, [FromBody] UpdateProductDto dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var sellerId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(sellerId))
                    return BadRequest(new { Message = "Seller ID not found." });

                var success = await _productService.UpdateProductAsync(id, dto, sellerId);
                if (!success)
                    return NotFound(new { Message = "Product not found or you don't have permission to update it." });

                return Ok(new { Message = "Product updated successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "An error occurred while updating the product.", Error = ex.Message });
            }
        }

        // ✅ DELETE product - Requires authentication (Seller only, own products)
        [Authorize(Roles = "Seller")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            try
            {
                var sellerId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(sellerId))
                    return BadRequest(new { Message = "Seller ID not found." });

                var success = await _productService.DeleteProductAsync(id, sellerId);
                if (!success)
                    return NotFound(new { Message = "Product not found or you don't have permission to delete it." });

                return Ok(new { Message = "Product deleted successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "An error occurred while deleting the product.", Error = ex.Message });
            }
        }

        // ✅ GET search products - Anonymous access
        [AllowAnonymous]
        [HttpGet("search")]
        public async Task<IActionResult> SearchProducts([FromQuery] string? name, [FromQuery] string? category)
        {
            try
            {
                var products = await _productService.SearchProductsAsync(name ?? "", category ?? "");
                return Ok(products);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "An error occurred while searching products.", Error = ex.Message });
            }
        }

        // ✅ Admin only: DELETE any product
        [Authorize(Roles = "Admin")]
        [HttpDelete("admin/{id}")]
        public async Task<IActionResult> AdminDeleteProduct(int id)
        {
            try
            {
                // Admin can delete any product, so we pass empty string as sellerId
                // You might want to modify your service to handle admin deletion differently
                var product = await _productService.GetProductByIdAsync(id);
                if (product == null)
                    return NotFound(new { Message = "Product not found." });

                // For admin deletion, you might want to create a separate method
                // or modify the existing one to bypass seller check for admins
                var success = await _productService.DeleteProductAsync(id, product.SellerId);
                if (!success)
                    return NotFound(new { Message = "Product not found." });

                return Ok(new { Message = "Product deleted successfully by admin." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "An error occurred while deleting the product.", Error = ex.Message });
            }
        }
    }
}