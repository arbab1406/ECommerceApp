﻿using ECommerce.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ECommerce.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Buyer")] // Only Buyers can access
    public class CartController : ControllerBase
    {
        private readonly ICartService _cartService;

        public CartController(ICartService cartService)
        {
            _cartService = cartService;
        }

        // ✅ Add product to cart
        [HttpPost("add")]
        public async Task<IActionResult> AddToCart([FromQuery] int productId, [FromQuery] int quantity)
        {
            var buyerId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(buyerId))
                return Unauthorized("User not recognized.");

            await _cartService.AddToCartAsync(buyerId, productId, quantity);
            return Ok("Product added to cart.");
        }

        // ✅ Get current cart
        [HttpGet]
        public async Task<IActionResult> GetCart()
        {
            var buyerId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var cart = await _cartService.GetCartAsync(buyerId);
            return Ok(cart);
        }

        // ✅ Place order from cart
        [HttpPost("checkout")]
        public async Task<IActionResult> Checkout()
        {
            var buyerId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var order = await _cartService.PlaceOrderAsync(buyerId);
            return Ok(order);
        }
    }
}
