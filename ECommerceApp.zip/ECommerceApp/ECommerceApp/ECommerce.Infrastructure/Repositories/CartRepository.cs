﻿using ECommerce.Application.Interfaces;
using ECommerce.Domain.Entities;
using ECommerce.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.Infrastructure.Repositories
{
    public class CartRepository : ICartRepository
    {
        private readonly AppDbContext _context;

        public CartRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Cart> GetCartByIdAsync(int id)
        {
            return await _context.Carts
                                 .Include(c => c.Items)
                                 .FirstOrDefaultAsync(c => c.Id == id);
        }


        // Implement the new method
        public async Task<Cart?> GetByIdAsync(int cartId)
        {
            return await _context.Carts
                                 .Include(c => c.Items)
                                 .FirstOrDefaultAsync(c => c.Id == cartId);
        }

        public async Task AddCartAsync(Cart cart)
        {
            await _context.Carts.AddAsync(cart);
        }

        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }

        public async Task<List<Cart>> GetAllAsync()
        {
            return await _context.Carts
                                 .Include(c => c.Items)
                                 .ToListAsync();
        }
    }
}