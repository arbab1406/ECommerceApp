﻿using ECommerce.Application.Interfaces;
using ECommerce.Domain.Entities;
using ECommerce.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.Infrastructure.Repositories
{
    public class ProductRepository : GenericRepository<Product>, IProductRepository
    {
        private readonly AppDbContext _context;

        public ProductRepository(AppDbContext context) : base(context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Product>> GetProductsBySellerIdAsync(string sellerId)
        {
            return await _context.Products
                                 .Where(p => p.SellerId == sellerId)
                                 .Include(p => p.Seller)
                                 .ToListAsync();
        }

        // ✅ Use 'new' to hide base method (not override)
        public new async Task<IEnumerable<Product>> GetAllAsync()
        {
            return await _context.Products
                                 .Include(p => p.Seller)
                                 .ToListAsync();
        }

        // ✅ Use 'new' to hide base method (not override)
        public new async Task<Product> GetByIdAsync(int id)
        {
            return await _context.Products
                                 .Include(p => p.Seller)
                                 .FirstOrDefaultAsync(p => p.Id == id);
        }

        // ✅ Implementation of SearchProductsAsync (works with basic Product properties)
        public async Task<IEnumerable<Product>> SearchProductsAsync(string? name, string? category)
        {
            var query = _context.Products.Include(p => p.Seller).AsQueryable();

            // Filter by name if provided (case-insensitive partial match)
            if (!string.IsNullOrWhiteSpace(name))
            {
                query = query.Where(p => p.Name.ToLower().Contains(name.ToLower()) ||
                                        p.Description.ToLower().Contains(name.ToLower()));
            }

            // Filter by category if provided - you can modify this based on your actual Product properties
            // Option 1: If you have a Category property, uncomment the next line:
            // if (!string.IsNullOrWhiteSpace(category))
            // {
            //     query = query.Where(p => p.Category.ToLower() == category.ToLower());
            // }

            // Option 2: If you don't have Category, you could search in description or name:
            if (!string.IsNullOrWhiteSpace(category))
            {
                query = query.Where(p => p.Description.ToLower().Contains(category.ToLower()));
            }

            // Only return products with stock (assuming you have Stock property)
            query = query.Where(p => p.Stock > 0);

            return await query.OrderBy(p => p.Name).ToListAsync();
        }
    }
}