﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;
using ECommerce.Domain.Entities;

namespace ECommerce.Infrastructure.Data
{
    public static class DbSeeder
    {
        public static async Task SeedRolesAsync(IServiceProvider serviceProvider)
        {
            var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            var userManager = serviceProvider.GetRequiredService<UserManager<User>>();

            string[] roles = { "Buyer", "Seller", "Owner" };

            foreach (var role in roles)
            {
                if (!await roleManager.RoleExistsAsync(role))
                    await roleManager.CreateAsync(new IdentityRole(role));
            }

            // Seed Owner (Admin)
            var ownerEmail = "owner@ecommerce.com";
            var owner = await userManager.FindByEmailAsync(ownerEmail);

            if (owner == null)
            {
                owner = new User
                {
                    FullName = "System Owner",
                    UserName = ownerEmail,
                    Email = ownerEmail,
                    EmailConfirmed = true
                };

                var result = await userManager.CreateAsync(owner, "Owner@123");
                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(owner, "Owner");
                }
            }
        }
    }
}
