﻿using ECommerce.Domain.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.Infrastructure.Data
{
    public class AppDbContext : IdentityDbContext<User>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Product> Products { get; set; }
        public DbSet<Cart> Carts { get; set; }
        public DbSet<CartItem> CartItems { get; set; }
        public DbSet<Order> Orders { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder); // ✅ Essential for Identity configurations

            // 1. ✅ Configure the relationship between Product and User (Seller)
            builder.Entity<Product>()
                .HasOne(p => p.Seller)           // A Product has one Seller
                .WithMany(u => u.Products)       // A Seller (User) can have many Products
                .HasForeignKey(p => p.SellerId)  // The foreign key is Product.SellerId
                .OnDelete(DeleteBehavior.Restrict); // Prevent deleting a Seller who has products

            // 2. ✅ Fix decimal precision for Price and TotalAmount
            builder.Entity<Product>()
                .Property(p => p.Price)
                .HasPrecision(18, 2);

            builder.Entity<Order>()
                .Property(o => o.TotalAmount)
                .HasPrecision(18, 2);

            // 3. ✅ (Optional but Recommended) Configure the Cart -> User relationship
            // If your Cart has a User navigation property, it should also be configured.
            builder.Entity<Cart>()
                .HasOne(c => c.User)             // A Cart has one User (Purchaser)
                .WithMany()                      // A User can have many Carts? Or one? Usually one.
                .HasForeignKey(c => c.UserId)    // The foreign key is Cart.UserId
                .OnDelete(DeleteBehavior.Cascade); // Often, if a user is deleted, their cart is too.

            // 4. ✅ (Optional but Recommended) Configure the Order -> Cart relationship
            builder.Entity<Order>()
                .HasOne(o => o.Cart)             // An Order is based on one Cart
                .WithMany()                      // A Cart is used for one Order
                .HasForeignKey(o => o.CartId)    // The foreign key is Order.CartId
                .OnDelete(DeleteBehavior.Restrict); // Prevent deleting a Cart if an Order exists
        }
    }
}