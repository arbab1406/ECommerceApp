﻿using ECommerce.Application.DTOs;
using ECommerce.Application.Interfaces;
using ECommerce.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.Application.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;

        public ProductService(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public async Task<Product> AddProductAsync(CreateProductDto dto, string sellerId)
        {
            var product = new Product
            {
                Name = dto.Name,
                Price = dto.Price,
                Description = dto.Description,
                Stock = dto.Stock,
                SellerId = sellerId
            };

            await _productRepository.AddAsync(product);
            await _productRepository.SaveChangesAsync();

            return product;
        }

        public async Task<IEnumerable<Product>> GetAllProductsAsync()
        {
            return await _productRepository.GetAllAsync();
        }

        public async Task<IEnumerable<Product>> GetProductsBySellerIdAsync(string sellerId)
        {
            return await _productRepository.GetProductsBySellerIdAsync(sellerId);
        }

        public async Task<Product> GetProductByIdAsync(int id)
        {
            return await _productRepository.GetByIdAsync(id);
        }

        // ✅ UPDATED: Update product with security check
        public async Task<bool> UpdateProductAsync(int id, UpdateProductDto dto, string sellerId)
        {
            var product = await _productRepository.GetByIdAsync(id);

            if (product == null || product.SellerId != sellerId)
                return false; // Product doesn't exist or doesn't belong to this seller

            // Update the product properties
            product.Name = dto.Name;
            product.Price = dto.Price;
            product.Description = dto.Description;
            product.Stock = dto.Stock;

            _productRepository.Update(product);
            await _productRepository.SaveChangesAsync();

            return true;
        }

        // ✅ UPDATED: Delete product with security check
        public async Task<bool> DeleteProductAsync(int id, string sellerId)
        {
            var product = await _productRepository.GetByIdAsync(id);

            if (product == null || product.SellerId != sellerId)
                return false; // Product doesn't exist or doesn't belong to this seller

            _productRepository.Delete(product);
            await _productRepository.SaveChangesAsync();

            return true;
        }

        // ✅ NEW: Search products by name or category
        public async Task<IEnumerable<Product>> SearchProductsAsync(string name, string category)
        {
            // This is a simple implementation - you might want to add more advanced search logic
            var allProducts = await _productRepository.GetAllAsync();

            var query = allProducts.AsQueryable();

            if (!string.IsNullOrEmpty(name))
            {
                query = query.Where(p => p.Name.Contains(name, StringComparison.OrdinalIgnoreCase));
            }

            // Note: If you have a Category property on Product, you can add category filtering
            // if (!string.IsNullOrEmpty(category))
            // {
            //     query = query.Where(p => p.Category.Contains(category, StringComparison.OrdinalIgnoreCase));
            // }

            return query.ToList();
        }
    }
}