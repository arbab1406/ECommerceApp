﻿using ECommerce.Application.Interfaces;
using ECommerce.Domain.Entities;

namespace ECommerce.Application.Services
{
    public class CartService
    {
        private readonly ICartRepository _cartRepository;

        public CartService(ICartRepository cartRepository)
        {
            _cartRepository = cartRepository;
        }

        public async Task<Cart> CreateCartForUserAsync(string userId)
        {
            var cart = new Cart { UserId = userId };
            await _cartRepository.AddCartAsync(cart);
            await _cartRepository.SaveChangesAsync();
            return cart;
        }

        public async Task AddItemToCartAsync(int cartId, int productId, int quantity)
        {
            var cart = await _cartRepository.GetCartByIdAsync(cartId);
            if (cart == null) throw new Exception("Cart not found");

            var item = new CartItem
            {
                CartId = cart.Id,
                ProductId = productId,
                Quantity = quantity
            };

            cart.Items.Add(item);
            await _cartRepository.SaveChangesAsync();
        }
    }
}
