﻿namespace ECommerceApp.ECommerce.Application.DTOs
{
    public class CartDto
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }

    public class CreateCartDto
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}
