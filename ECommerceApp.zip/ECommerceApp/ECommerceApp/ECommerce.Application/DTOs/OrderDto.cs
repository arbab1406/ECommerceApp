﻿namespace ECommerce.Application.DTOs
{
    public class CreateOrderDto
    {
        public int CartId { get; set; }
    }

    public class OrderDto
    {
        public int Id { get; set; }
        public int CartId { get; set; }
        public DateTime OrderDate { get; set; }
        public decimal TotalAmount { get; set; }
        public string Status { get; set; }
    }
}
