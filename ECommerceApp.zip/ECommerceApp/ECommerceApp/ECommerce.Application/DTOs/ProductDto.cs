﻿// Use this DTO for CREATE and UPDATE operations (input)
public class CreateProductDto
{
    public string Name { get; set; }
    public decimal Price { get; set; }
    public int Stock { get; set; }
    public string? Description { get; set; }
    // We do NOT include SellerId here. It will come from the logged-in user's token.
}

// Use this DTO for GET operations (output)
public class ProductDto
{
    public int Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
    public int Stock { get; set; }
    public string? Description { get; set; }
    // Optional: Include seller name if you want to display it
    public string SellerName { get; set; }
}