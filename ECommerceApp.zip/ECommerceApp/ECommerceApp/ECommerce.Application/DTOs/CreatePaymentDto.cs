﻿// CreatePaymentDto.cs
namespace ECommerce.Application.DTOs
{
    public class CreatePaymentDto
    {
        public decimal Amount { get; set; }
        public string Currency { get; set; } = "usd";
        public string PaymentMethodId { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string? ReturnUrl { get; set; }
    }
}