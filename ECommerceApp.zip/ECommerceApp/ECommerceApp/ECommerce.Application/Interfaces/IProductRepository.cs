﻿using ECommerce.Domain.Entities;

namespace ECommerce.Application.Interfaces
{
    public interface IProductRepository : IGenericRepository<Product>
    {
        Task<IEnumerable<Product>> GetProductsBySellerIdAsync(string sellerId);

        // ✅ Optional: Add search method to repository for better performance
        Task<IEnumerable<Product>> SearchProductsAsync(string name, string category);
    }
}