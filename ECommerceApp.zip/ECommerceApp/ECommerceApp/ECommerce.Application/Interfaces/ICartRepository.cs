﻿using ECommerce.Domain.Entities;

namespace ECommerce.Application.Interfaces
{
    public interface ICartRepository
    {
        Task<Cart> GetCartByIdAsync(int id);
        Task<Cart?> GetByIdAsync(int cartId); // Add this method
        Task AddCartAsync(Cart cart);
        Task SaveChangesAsync();
        Task<List<Cart>> GetAllAsync(); // This should return Task<List<Cart>>
    }
}