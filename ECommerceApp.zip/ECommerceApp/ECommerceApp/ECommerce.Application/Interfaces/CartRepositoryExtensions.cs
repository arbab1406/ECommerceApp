﻿// Add this in a new file, e.g., CartRepositoryExtensions.cs
using ECommerce.Domain.Entities;

namespace ECommerce.Application.Interfaces
{
    public static class CartRepositoryExtensions
    {
        public static async Task<Cart?> GetCartByIdAsync(this ICartRepository repository, int cartId)
        {
            // Try to use reflection to call the existing method
            var method = repository.GetType().GetMethod("GetByIdAsync");
            if (method != null)
            {
                var task = (Task)method.Invoke(repository, new object[] { cartId });
                await task;

                // Check if the repository has a property with the result
                var resultProperty = repository.GetType().GetProperty("CurrentCart");
                if (resultProperty != null)
                {
                    return resultProperty.GetValue(repository) as Cart;
                }
            }

            // Fallback to synchronous method
            var syncMethod = repository.GetType().GetMethod("GetById");
            if (syncMethod != null)
            {
                return syncMethod.Invoke(repository, new object[] { cartId }) as Cart;
            }

            throw new Exception("Cannot retrieve cart using available methods");
        }
    }
}