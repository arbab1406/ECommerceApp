﻿namespace ECommerce.Application.Interfaces
{
    public interface IOrderService
    {
        Task<ECommerce.Domain.Entities.Order> PlaceOrderAsync(string buyerId);
        Task<IEnumerable<ECommerce.Domain.Entities.Order>> GetOrdersBySellerAsync(string sellerId);
        Task<IEnumerable<ECommerce.Domain.Entities.Order>> GetOrdersByBuyerAsync(string buyerId);
        Task<ECommerce.Domain.Entities.Order> GetOrderByIdAsync(int orderId);
        Task<bool> IsSellerOrderAsync(int orderId, string sellerId);
        Task<bool> UpdateOrderStatusAsync(int orderId, string sellerId, string status);
        Task<bool> CancelOrderAsync(int orderId, string buyerId);
    }
}