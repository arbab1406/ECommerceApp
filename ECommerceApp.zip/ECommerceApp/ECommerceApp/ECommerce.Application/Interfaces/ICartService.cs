﻿using ECommerce.Domain.Entities;

namespace ECommerce.Application.Interfaces
{
    public interface ICartService
    {
        Task AddToCartAsync(string buyerId, int productId, int quantity);
        Task<IEnumerable<CartItem>> GetCartAsync(string buyerId);

        // ✅ Add PlaceOrderAsync
        Task<Order> PlaceOrderAsync(string buyerId);
    }
}
