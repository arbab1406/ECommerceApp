﻿// ✅ Ensure this namespace matches
namespace ECommerce.Domain.Entities
{
    public class Order
    {
        public int Id { get; set; }
        public int CartId { get; set; } // FK to Cart
        public Cart Cart { get; set; }
        public DateTime OrderDate { get; set; } = DateTime.UtcNow;
        public decimal TotalAmount { get; set; }
        public string Status { get; set; } = "Pending";

        // You might want to add these properties for better order management:
        public string BuyerId { get; set; } // ID of the user who placed the order
        public User Buyer { get; set; } // Navigation property to buyer
    }
}