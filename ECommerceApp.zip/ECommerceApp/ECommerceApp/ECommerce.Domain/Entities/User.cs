﻿using Microsoft.AspNetCore.Identity;

namespace ECommerce.Domain.Entities
{
    public class User : IdentityUser
    {
        public string FullName { get; set; }

        // ✅ NAVIGATION PROPERTY: A seller can have many listed products.
        public ICollection<Product> Products { get; set; } = new List<Product>();
    }
}